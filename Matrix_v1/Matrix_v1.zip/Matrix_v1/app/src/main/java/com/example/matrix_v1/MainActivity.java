package com.example.matrix_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    static float[][] matriz;
    static float[] valoresmatriz;
    static float determinante;
    float[] arregloaEnviar;
    TextView txtRenglonUno_1,txtRenglonUno_2,txtRenglonUno_3,txtRenglonUno_4,txtRenglonUno_5, txtRenglonUno_a;
    TextView txtRenglonDos_1,txtRenglonDos_2,txtRenglonDos_3,txtRenglonDos_4,txtRenglonDos_5, txtRenglonDos_b;
    TextView txtRenglonTres_1,txtRenglonTres_2,txtRenglonTres_3,txtRenglonTres_4,txtRenglonTres_5, txtRenglonTres_c;
    int contador;
    String titulo;
    String descripcion;
    Intent next, next2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contador=2;


        txtRenglonUno_1 = findViewById(R.id.txt1);
        txtRenglonUno_2 = findViewById(R.id.txt2);
        txtRenglonUno_3 = findViewById(R.id.txt3);
        txtRenglonUno_a = findViewById(R.id.txtA);

        txtRenglonDos_1 = findViewById(R.id.txt6);
        txtRenglonDos_2 = findViewById(R.id.txt7);
        txtRenglonDos_3 = findViewById(R.id.txt8);

        txtRenglonDos_b = findViewById(R.id.txtB);

        txtRenglonTres_1 = findViewById(R.id.txt11);
        txtRenglonTres_2 = findViewById(R.id.txt12);
        txtRenglonTres_3 = findViewById(R.id.txt13);

        txtRenglonTres_c = findViewById(R.id.txtC);

        interpretarContadorTextViews(contador);




        final Button btnMenos = findViewById(R.id.btnMenos);
        final Button btnMas = findViewById(R.id.btnMas);
        btnMenos.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (contador ==3) {
                    contador --;

                }
                interpretarContadorTextViews(contador);

             }
        });
        btnMas.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                if (contador ==2) {
                    contador ++;

                }

                interpretarContadorTextViews(contador);
            }
        });

        final Button btnCombinacionLineal = findViewById(R.id.btnUno);
        btnCombinacionLineal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x=0;
                next = new Intent(MainActivity.this, CombLinealActivity.class);
                    startActivity(next);

            }
        });

        final Button btnIndependenciaLineal = findViewById(R.id.btnDos);
        btnIndependenciaLineal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int flag =0;
                    next = new Intent(MainActivity.this, OperacionesActivity.class);
                    titulo = " Independencia lineal";
                    descripcion = "Un conjunto de vectores es linealmente independiente si ninguno de ellos puede ser escrito con una combinación lineal de los restantes.";
                    String compInd = "";
                    next.putExtra("contador",contador);
                    next.putExtra("titulo",titulo);
                    next.putExtra("descripcion",descripcion);
               try{
                    mandarDatos(contador);
                }catch(Exception e){
                    int duration= Toast.LENGTH_SHORT;
                    Toast.makeText(MainActivity.this, "Introduzca los valores",duration).show();
                    flag=1;
                }
                if(flag==0) {
                    compInd = comprobarIndependencia();
                    next.putExtra("comp", compInd);
                    next.putExtra("arreglo", arregloaEnviar);
                    next.putExtra("arreglo2", valoresmatriz);
                    startActivity(next);
                }flag=0;
            }
        });
        final Button btnCambioBase = findViewById(R.id.btnTres);
        btnCambioBase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int flag=0;
               next = new Intent(MainActivity.this, OperacionesActivity.class);
                titulo = "conjunto generador en base "+contador+"x"+contador;
                descripcion = "Se llama sistema generador de V a un conjunto de vectores, pertenecientes a V, a partir del cual se puede generar el espacio vectorial V completo.";
                next.putExtra("contador",contador);
                next.putExtra("titulo",titulo);
                next.putExtra("descripcion",descripcion);
                try{
                    mandarDatos(contador);
                }catch(Exception e){
                    int duration= Toast.LENGTH_SHORT;
                    Toast.makeText(MainActivity.this, "Introduzca los valores",duration).show();
                    flag=1;
                }
                if (flag==0) {
                    String compBase = comprobarBase();
                    next.putExtra("comp", compBase);
                    next.putExtra("arreglo", arregloaEnviar);
                    next.putExtra("arreglo2", valoresmatriz);
                    startActivity(next);
                }flag=0;
            }
        });

        final Button btnArrow = findViewById(R.id.btnArrow);
        btnArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int duration= Toast.LENGTH_SHORT;
                Toast.makeText(MainActivity.this, "Proyecto para TecNM",duration).show();
            }
        });
    }

    public void interpretarContadorTextViews(int cont){
        matriz = new float[cont][cont + 1];
        switch (cont){
            case (2):
                txtRenglonUno_1.setVisibility(View.VISIBLE);
                txtRenglonUno_2.setVisibility(View.VISIBLE);
                txtRenglonDos_1.setVisibility(View.VISIBLE);
                txtRenglonDos_2.setVisibility(View.VISIBLE);
                txtRenglonUno_3.setVisibility(View.INVISIBLE);
                txtRenglonDos_3.setVisibility(View.INVISIBLE);
                txtRenglonTres_1.setVisibility(View.INVISIBLE);
                txtRenglonTres_2.setVisibility(View.INVISIBLE);
                txtRenglonTres_3.setVisibility(View.INVISIBLE);


                txtRenglonUno_a.setVisibility(View.VISIBLE);
                txtRenglonDos_b.setVisibility(View.VISIBLE);

                txtRenglonUno_3.setVisibility(View.INVISIBLE);
                txtRenglonDos_3.setVisibility(View.INVISIBLE);

                txtRenglonUno_1.setEnabled(true);
                txtRenglonUno_2.setEnabled(true);
                txtRenglonDos_1.setEnabled(true);
                txtRenglonDos_2.setEnabled(true);
                txtRenglonUno_a.setEnabled(true);
                txtRenglonDos_b.setEnabled(true);
                txtRenglonUno_3.setEnabled(false);
                txtRenglonDos_3.setEnabled(false);
                txtRenglonTres_1.setEnabled(false);
                txtRenglonTres_2.setEnabled(false);
                txtRenglonTres_3.setEnabled(false);
                txtRenglonTres_c.setEnabled(false);
                txtRenglonTres_c.setVisibility(View.INVISIBLE);



                break;
            case (3):
                txtRenglonUno_3.setVisibility(View.VISIBLE);
                txtRenglonDos_3.setVisibility(View.VISIBLE);
                txtRenglonTres_1.setVisibility(View.VISIBLE);
                txtRenglonTres_2.setVisibility(View.VISIBLE);
                txtRenglonTres_3.setVisibility(View.VISIBLE);

                txtRenglonTres_c.setEnabled(true);
                txtRenglonTres_c.setVisibility(View.VISIBLE);



                txtRenglonUno_3.setEnabled(true);
                txtRenglonDos_3.setEnabled(true);
                txtRenglonTres_1.setEnabled(true);
                txtRenglonTres_2.setEnabled(true);
                txtRenglonTres_3.setEnabled(true);




                break;
        }
    }

    public void mandarDatos(int contador) {
       next2 = new Intent(MainActivity.this, OperacionesActivity.class);

        switch (contador) {
            case (2):
                    TextView[] txtViews2x2 = {txtRenglonUno_1,txtRenglonUno_2, txtRenglonUno_a, txtRenglonDos_1,txtRenglonDos_2, txtRenglonDos_b};
                    arregloaEnviar = new float[txtViews2x2.length];
                    llenarMatriz();
                    gaussjordan(txtViews2x2, contador);
                    break;
                    case (3):
                        TextView[] txtViews3x3 = { txtRenglonUno_1,txtRenglonUno_2,txtRenglonUno_3, txtRenglonUno_a,
                                txtRenglonDos_1,txtRenglonDos_2,txtRenglonDos_3, txtRenglonDos_b, txtRenglonTres_1,txtRenglonTres_2,txtRenglonTres_3, txtRenglonTres_c};
                        arregloaEnviar = new float[txtViews3x3.length];
                        llenarMatriz();
                        gaussjordan(txtViews3x3, contador);

                        break;
                }

        }

        public  void llenarMatriz(){

            switch (contador){
                case(2):
                    float uno2x2 = Float.parseFloat(txtRenglonUno_1.getText().toString());
                    float dos2x2 = Float.parseFloat(txtRenglonUno_2.getText().toString());
                    float a2x2 = Float.parseFloat(txtRenglonUno_a.getText().toString());


                    float tres2x2 = Float.parseFloat(txtRenglonDos_1.getText().toString());
                    float cuatro2x2 = Float.parseFloat(txtRenglonDos_2.getText().toString());
                    float b2x2 = Float.parseFloat(txtRenglonDos_b.getText().toString());

                    matriz[0][0] =  uno2x2;
                    matriz[0][1] =  dos2x2;
                    matriz[0][2] =  a2x2;

                    matriz[1][0] =  tres2x2;
                    matriz[1][1] =  cuatro2x2;
                    matriz[1][2] =  b2x2;



                    break;

                case(3):
                    float uno3x3 = Float.parseFloat(txtRenglonUno_1.getText().toString());
                    float dos3x3 = Float.parseFloat(txtRenglonUno_2.getText().toString());
                    float tres3x3 = Float.parseFloat(txtRenglonUno_3.getText().toString());
                    float a3x3 = Float.parseFloat(txtRenglonUno_a.getText().toString());

                    float cuatro3x3 = Float.parseFloat(txtRenglonDos_1.getText().toString());
                    float cinco3x3 = Float.parseFloat(txtRenglonDos_2.getText().toString());
                    float seis3x3 = Float.parseFloat(txtRenglonDos_3.getText().toString());
                    float b3x3 = Float.parseFloat(txtRenglonDos_b.getText().toString());

                    float siete3x3 = Float.parseFloat(txtRenglonTres_1.getText().toString());
                    float ocho3x3 = Float.parseFloat(txtRenglonTres_2.getText().toString());
                    float nueve3x3 = Float.parseFloat(txtRenglonTres_3.getText().toString());
                    float c3x3 = Float.parseFloat(txtRenglonTres_c.getText().toString());

                    matriz[0][0] = uno3x3;
                    matriz[0][1] = dos3x3;
                    matriz[0][2] = tres3x3;
                    matriz[0][3] = a3x3;

                    matriz[1][0] = cuatro3x3;
                    matriz[1][1] = cinco3x3;
                    matriz[1][2] = seis3x3;
                    matriz[1][3] = b3x3;

                    matriz[2][0] = siete3x3;
                    matriz[2][1] = ocho3x3;
                    matriz[2][2] = nueve3x3;
                    matriz[2][3] = c3x3;
                    break;

            }
            int i=0;

            valoresmatriz = new float[30];
            for (int x=0; x<contador; x++){
                for (int y=0; y<contador+1; y++){

                    valoresmatriz[i]=matriz[x][y];
                    i++;
                }
            }

        }

        static void pivote(float matriz[][], int piv, int var) {
            float temp = 0;
            temp = matriz[piv][piv];
            for (int y = 0; y < (var + 1); y++) {

                matriz[piv][y] = matriz[piv][y] / temp;
            }
        }

        static void hacerceros(float matriz[][], int piv, int var) {
            for (int x = 0; x < var; x++) {
                if (x != piv) {
                    float c = matriz[x][piv];
                    for (int z = 0; z < (var + 1); z++) {
                        matriz[x][z] = ((-1 * c) * matriz[piv][z]) + matriz[x][z];
                    }
                }
            }
        }

        public void muestramatriz(float matriz[][], int var,TextView[] txts) {
        int i=0;
        for (int x = 0; x < var; x++) {
            for (int y = 0; y < (var+1); y++) {
                if (!Float.isNaN(matriz[x][y])) {
                    if(!Float.isInfinite(matriz[x][y])) {
                        arregloaEnviar[i] = matriz[x][y];
                        i++;
                    }
                }


            }

        }


    }

        public  void gaussjordan(TextView[] txts, int contador) {
            int piv = 0;

            for (int a = 0; a < contador; a++) {
                pivote(matriz, piv, contador);
                hacerceros(matriz, piv, contador);
                piv++;


                    muestramatriz(matriz,contador,txts);


            }

        }
        public String comprobarIndependencia(){
        String verificar;
        determinante = calcDeterminante(matriz, contador);

            //int duration= Toast.LENGTH_SHORT;
            //Toast.makeText(MainActivity.this, "El det: "+determinante,duration).show();

                if(Float.isNaN(determinante) || Float.isInfinite(determinante) || determinante==0){
                    verificar = "No tiene ";
                }else{
                    verificar = "Sí tiene ";
                }
        return verificar;
        }

        public String comprobarBase(){
        String comprobar="";
        String matrix =""+matriz[contador-1][contador-1];
        if(matrix.equals("0.0") || matrix.equals("NaN")){
            comprobar = "No es";
        }else{
            comprobar= "Sí es ";
        }

        return comprobar;
        }

    static float calcDeterminante(float[][] a,int orden){
        float aux;
        float det=1;
        for(int k=0;k<orden-1;k++){
            det=det*a[k][k];
            if(a[k][k]==0 || Float.isNaN(a[k][k]))
                return 0;
            else{
                for(int i=k+1;i<orden;i++){
                    aux=-a[i][k];
                    for(int j=k;j<orden;j++){
                        a[i][j]=a[i][j]+aux*a[k][j]/a[k][k];
                    }
                }
            }
        }
        det=det*a[orden-1][orden-1];
        return det;
    }
}
